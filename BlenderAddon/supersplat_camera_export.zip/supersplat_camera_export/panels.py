"""
UI Panels for SuperSplat Camera Export addon
"""

import bpy
from bpy.types import Panel

class SUPERSPLAT_PT_camera_export(Panel):
    """Export panel for SuperSplat camera export"""
    bl_label = "Export Camera Animation"
    bl_idname = "SUPERSPLAT_PT_camera_export"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SuperSplat"
    bl_parent_id = "SUPERSPLAT_PT_curve_animation"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        props = scene.supersplat_camera
        
        # Step 2 header
        box = layout.box()
        row = box.row()
        row.label(text="2. Export to SuperSplat", icon='EXPORT')
        
        # Camera selection
        box = layout.box()
        box.label(text="Camera Selection:", icon='OUTLINER_OB_CAMERA')
        
        col = box.column()
        col.prop(props, "selected_camera", text="Camera")
        
        # Quick select buttons for cameras
        if len([obj for obj in context.scene.objects if obj.type == 'CAMERA']) > 0:
            row = col.row(align=True)
            for obj in context.scene.objects:
                if obj.type == 'CAMERA':
                    op = row.operator("supersplat.select_camera", text=obj.name, icon='CAMERA_DATA')
                    op.camera_name = obj.name
        else:
            col.label(text="No cameras in scene", icon='ERROR')
        
        # Output settings
        box = layout.box()
        box.label(text="Output Settings:", icon='FILE')
        
        col = box.column()
        col.prop(props, "auto_filename")
        col.prop(props, "output_path", text="Path")
        
        # Status and validation
        box = layout.box()
        row = box.row()
        if props.validation_error:
            row.label(text="Status:", icon='ERROR')
        else:
            row.label(text="Status:", icon='CHECKMARK')
        
        col = box.column()
        col.label(text=props.validation_status)
        
        row = col.row(align=True)
        row.operator("supersplat.validate_setup", icon='FILE_REFRESH')
        
        # Export button
        layout.separator()
        row = layout.row()
        row.scale_y = 1.5
        
        if props.validation_error:
            row.enabled = False
            
        row.operator("supersplat.export_camera", icon='EXPORT', text="Export to SuperSplat")


class SUPERSPLAT_PT_export_settings(Panel):
    """Export settings panel"""
    bl_label = "Export Settings"
    bl_idname = "SUPERSPLAT_PT_export_settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SuperSplat"
    bl_parent_id = "SUPERSPLAT_PT_curve_animation"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        props = scene.supersplat_camera
        
        # Coordinate system
        box = layout.box()
        box.label(text="Coordinate System:", icon='ORIENTATION_GLOBAL')
        
        col = box.column()
        col.prop(props, "coordinate_system", expand=True)
        
        # Target distance
        col.separator()
        col.prop(props, "target_distance")
        
        # Export options
        box = layout.box()
        box.label(text="Export Options:", icon='SETTINGS')
        
        col = box.column()
        col.prop(props, "include_focal_length")
        col.prop(props, "include_fov")
        col.prop(props, "include_metadata")
        col.prop(props, "coordinate_precision")


class SUPERSPLAT_PT_frame_settings(Panel):
    """Frame range settings panel"""
    bl_label = "Frame Range"
    bl_idname = "SUPERSPLAT_PT_frame_settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SuperSplat"
    bl_parent_id = "SUPERSPLAT_PT_curve_animation"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        props = scene.supersplat_camera
        
        # Frame range selection
        col = layout.column()
        col.prop(props, "use_scene_frame_range")
        
        if props.use_scene_frame_range:
            # Show scene frame range (read-only)
            row = col.row(align=True)
            row.enabled = False
            row.prop(scene, "frame_start", text="Start")
            row.prop(scene, "frame_end", text="End")
        else:
            # Custom frame range
            row = col.row(align=True)
            row.prop(props, "frame_start", text="Start")
            row.prop(props, "frame_end", text="End")
        
        col.separator()
        col.prop(props, "frame_step")
        
        # Frame info
        if props.use_scene_frame_range:
            frame_count = len(range(scene.frame_start, scene.frame_end + 1, props.frame_step))
        else:
            frame_count = len(range(props.frame_start, props.frame_end + 1, props.frame_step))
        
        col.separator()
        row = col.row()
        row.alignment = 'CENTER'
        row.label(text=f"Frames to export: {frame_count}", icon='TIME')


class SUPERSPLAT_PT_curve_animation(Panel):
    """Main SuperSplat panel - curve animation creation"""
    bl_label = "SuperSplat Camera Tools"
    bl_idname = "SUPERSPLAT_PT_curve_animation"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SuperSplat"
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        props = scene.supersplat_camera
        
        # Main header
        row = layout.row()
        row.label(text="Create Camera Animations", icon='CAMERA_DATA')
        
        # Info box
        box = layout.box()
        row = box.row()
        row.label(text="1. Create Animation Along Curve", icon='CURVE_BEZCURVE')
        
        # Camera and curve selection
        col = layout.column()
        col.label(text="Setup:", icon='SETTINGS')
        
        # Camera selection for curve animation
        col.prop(props, "curve_camera", text="Camera")
        
        # Path curve selection
        col.prop(props, "path_curve", text="Path Curve")
        
        # Target settings
        col.separator()
        col.label(text="Target Settings:", icon='TRACKING')
        col.prop(props, "track_target", text="Track Target")
        col.prop(props, "track_target_empty", text="Create Track Target")
        
        # Animation settings
        col.separator()
        col.label(text="Animation:", icon='TIME')
        col.prop(props, "curve_frame_start", text="Start Frame")
        col.prop(props, "curve_frame_end", text="End Frame")
        col.prop(props, "follow_curve_path", text="Animate Along Path")
        col.prop(props, "use_curve_follow", text="Follow Curve Direction")
        
        # Attachment settings
        col.separator()
        col.label(text="Attachment:", icon='CONSTRAINT')
        col.prop(props, "attach_to_curve", text="Attach to Curve")
        
        if props.attach_to_curve:
            col.prop(props, "attach_to_start", text="Attach to Start Point")
            if not props.attach_to_start:
                col.prop(props, "curve_offset", text="Path Offset")
        else:
            col.prop(props, "curve_offset", text="Path Offset")
        
        # Create animation button
        layout.separator()
        row = layout.row()
        row.scale_y = 1.5
        
        # Disable if no camera or curve selected
        if not props.curve_camera or not props.path_curve:
            row.enabled = False
            
        row.operator("supersplat.create_curve_animation", icon='PLAY', text="Create Animation")
        
        # Help text
        if not props.curve_camera or not props.path_curve:
            col = layout.column()
            col.scale_y = 0.8
            col.label(text="Select camera and curve above", icon='INFO')


class SUPERSPLAT_PT_diagnostics(Panel):
    """Diagnostics panel"""
    bl_label = "Diagnostics"
    bl_idname = "SUPERSPLAT_PT_diagnostics"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SuperSplat"
    bl_parent_id = "SUPERSPLAT_PT_curve_animation"
    bl_options = {'DEFAULT_CLOSED'}
    
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        props = scene.supersplat_camera
        
        # Testing tools
        box = layout.box()
        box.label(text="Testing Tools:", icon='TOOL_SETTINGS')
        
        col = box.column()
        col.operator("supersplat.test_camera_sampling", icon='CAMERA_DATA', text="Test Camera Sampling")
        
        # Frame step recommendations
        col.separator()
        col.label(text="Frame Step Recommendations:", icon='INFO')
        
        info_col = col.column(align=True)
        info_col.scale_y = 0.8
        info_col.label(text="• For smooth circular motion: 1-5")
        info_col.label(text="• For faster export: 10-25")
        info_col.label(text="• Current step may miss frames")
        
        # Current settings summary
        col.separator()
        if props.frame_step > 50:
            row = col.row()
            row.alert = True
            row.label(text=f"⚠️  Step {props.frame_step} may be too large", icon='ERROR')
        elif props.frame_step <= 5:
            row = col.row()
            row.label(text=f"✅ Step {props.frame_step} should capture motion", icon='CHECKMARK')
        else:
            row = col.row()
            row.label(text=f"Step {props.frame_step} - test sampling below", icon='QUESTION')
