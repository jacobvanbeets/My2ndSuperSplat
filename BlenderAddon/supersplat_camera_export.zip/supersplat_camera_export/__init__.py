"""
SuperSplat Camera Tools - Blender Addon
=======================================

Create curve-based camera animations and export animated camera data from Blender to JSON format for SuperSplat.

Features:
- Create smooth camera animations along curves
- Set up camera tracking to targets
- Export camera poses to SuperSplat-compatible JSON format
- Diagnostic tools for animation testing

Author: BB6
Version: 2.0.1
Blender: 3.0+
"""

bl_info = {
    "name": "SuperSplat Camera Tools v2",
    "author": "BB6",
    "version": (2, 0, 1),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Cam2SuperSplat Panel",
    "description": "Create curve-based camera animations and export to JSON format for SuperSplat",
    "warning": "",
    "doc_url": "https://github.com/playcanvas/supersplat",
    "category": "Import-Export",
}

import bpy
from bpy.props import (
    StringProperty,
    BoolProperty,
    IntProperty,
    FloatProperty,
    EnumProperty,
    PointerProperty,
)
from bpy.types import (
    Panel,
    Operator,
    PropertyGroup,
    AddonPreferences,
)

# Import our modules
from . import operators
from . import panels
from . import properties

# List of classes to register
classes = (
    # Properties
    properties.SuperSplatCameraExportProperties,
    
    # Operators
    operators.SUPERSPLAT_OT_export_camera,
    operators.SUPERSPLAT_OT_select_camera,
    operators.SUPERSPLAT_OT_validate_setup,
    operators.SUPERSPLAT_OT_create_curve_animation,
    # operators.SUPERSPLAT_OT_test_camera_sampling,  # Temporarily disabled due to Blender caching
    
    # Panels
    panels.SUPERSPLAT_PT_curve_animation,
    panels.SUPERSPLAT_PT_camera_export,
    panels.SUPERSPLAT_PT_export_settings,
    panels.SUPERSPLAT_PT_frame_settings,
    # panels.SUPERSPLAT_PT_diagnostics,  # Temporarily disabled
)

def register():
    """Register all classes and properties"""
    
    # Register classes
    for cls in classes:
        bpy.utils.register_class(cls)
    
    # Add properties to scene
    bpy.types.Scene.supersplat_camera = PointerProperty(
        type=properties.SuperSplatCameraExportProperties
    )
    
    print("SuperSplat Camera Export addon registered successfully!")

def unregister():
    """Unregister all classes and properties"""
    
    # Remove properties from scene
    if hasattr(bpy.types.Scene, 'supersplat_camera'):
        del bpy.types.Scene.supersplat_camera
    
    # Unregister classes (in reverse order)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    print("SuperSplat Camera Export addon unregistered!")

# This allows running the script directly in Blender's text editor
if __name__ == "__main__":
    register()
