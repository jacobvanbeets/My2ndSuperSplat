"""
Operators for SuperSplat Camera Export addon
"""

import bpy
import bmesh
import mathutils
from mathutils import Vector, Matrix
import json
import os
import math
from datetime import datetime
from bpy.types import Operator
from bpy.props import StringProperty

class SUPERSPLAT_OT_export_camera(Operator):
    """Export camera animation to JSON for SuperSplat"""
    bl_idname = "supersplat.export_camera"
    bl_label = "Export Camera Animation"
    bl_description = "Export selected camera animation to JSON format"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        """Execute the export operation"""
        scene = context.scene
        props = scene.supersplat_camera
        
        # Validate settings
        if not self.validate_settings(props):
            return {'CANCELLED'}
        
        try:
            # Get camera object
            camera_obj = bpy.data.objects.get(props.selected_camera)
            if not camera_obj:
                self.report({'ERROR'}, "Selected camera not found!")
                return {'CANCELLED'}
            
            # Debug: Check if camera has animation data
            debug_msg = f"\n=== CAMERA ANIMATION DEBUG ===\n"
            debug_msg += f"Camera name: {camera_obj.name}\n"
            debug_msg += f"Has animation data: {camera_obj.animation_data is not None}\n"
            
            if camera_obj.animation_data:
                debug_msg += f"Has action: {camera_obj.animation_data.action is not None}\n"
                if camera_obj.animation_data.action:
                    fcurves = camera_obj.animation_data.action.fcurves
                    debug_msg += f"F-curves count: {len(fcurves)}\n"
                    for i, fcurve in enumerate(fcurves):
                        debug_msg += f"  F-curve {i}: {fcurve.data_path}[{fcurve.array_index}] - {len(fcurve.keyframe_points)} keyframes\n"
                else:
                    debug_msg += "No action found - camera may not be animated\n"
            else:
                debug_msg += "No animation data found - camera is not animated\n"
            
            debug_msg += "=============================="
            
            # Show debug in both console and UI
            print(debug_msg)
            self.report({'INFO'}, "Debug info printed to console - check Window > Toggle System Console")
            
            # Perform export
            success = self.export_camera_animation(camera_obj, props)
            
            if success:
                self.report({'INFO'}, f"Camera animation exported successfully to {props.output_path}")
                return {'FINISHED'}
            else:
                return {'CANCELLED'}
                
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {str(e)}")
            return {'CANCELLED'}
    
    def validate_settings(self, props):
        """Validate export settings"""
        if props.selected_camera == "NONE":
            self.report({'ERROR'}, "No camera selected!")
            return False
        
        if not props.output_path:
            self.report({'ERROR'}, "No output path specified!")
            return False
        
        # Validate frame range
        if not props.use_scene_frame_range:
            if props.frame_start >= props.frame_end:
                self.report({'ERROR'}, "Start frame must be less than end frame!")
                return False
        
        return True
    
    def get_camera_data_at_frame(self, camera_obj, frame, props):
        """Get camera position, target, and focal length at a specific frame"""
        
        # Set the current frame
        print(f"\nDEBUG: Setting frame to {frame}")
        bpy.context.scene.frame_set(frame)
        
        # Update the scene to ensure all transformations are applied
        bpy.context.view_layer.update()
        
        # Get camera world matrix
        camera_matrix = camera_obj.matrix_world.copy()
        print(f"DEBUG: Camera matrix at frame {frame}:")
        for i, row in enumerate(camera_matrix):
            print(f"  Row {i}: {[round(v, 4) for v in row]}")
        
        # Camera position is the translation component
        camera_pos = camera_matrix.translation
        print(f"DEBUG: Raw camera position: {[round(v, 4) for v in camera_pos]}")
        
        # Camera forward direction (negative Z in Blender's camera space)
        camera_forward = -camera_matrix.col[2].xyz.normalized()
        print(f"DEBUG: Camera forward: {[round(v, 4) for v in camera_forward]}")
        
        # Calculate target position (point the camera is looking at)
        target_pos = camera_pos + (camera_forward * props.target_distance)
        print(f"DEBUG: Raw target position: {[round(v, 4) for v in target_pos]}")
        
        # Apply coordinate system conversion if needed
        if props.coordinate_system == 'SUPERSPLAT':
            print(f"DEBUG: Converting coordinates from Blender to SuperSplat")
            print(f"  Before: camera_pos = {[round(v, 4) for v in camera_pos]}")
            print(f"  Before: target_pos = {[round(v, 4) for v in target_pos]}")
            
            # Convert from Blender Z-up to SuperSplat Y-up: [x, y, z] -> [x, z, -y]
            camera_pos = Vector([camera_pos.x, camera_pos.z, -camera_pos.y])
            target_pos = Vector([target_pos.x, target_pos.z, -target_pos.y])
            
            print(f"  After:  camera_pos = {[round(v, 4) for v in camera_pos]}")
            print(f"  After:  target_pos = {[round(v, 4) for v in target_pos]}")
        
        # Round coordinates to specified precision
        precision = props.coordinate_precision
        camera_pos = [round(coord, precision) for coord in camera_pos]
        target_pos = [round(coord, precision) for coord in target_pos]
        
        # Get camera data (focal length and FOV)
        focal_length = None
        fov_degrees = None
        
        if props.include_focal_length or props.include_fov:
            focal_length = camera_obj.data.lens
            
            # Calculate FOV from focal length
            # FOV = 2 * arctan(sensor_width / (2 * focal_length))
            sensor_width = camera_obj.data.sensor_width  # Default 36mm for Full Frame
            fov_radians = 2 * math.atan(sensor_width / (2 * focal_length))
            fov_degrees = math.degrees(fov_radians)
            
            print(f"DEBUG: Focal length: {focal_length}mm, Sensor: {sensor_width}mm, FOV: {fov_degrees:.2f}°")
        
        frame_data = {
            'frame': frame,
            'time': frame / bpy.context.scene.render.fps,
            'position': camera_pos,
            'target': target_pos,
            'name': f"{camera_obj.name}_frame_{frame:04d}"
        }
        
        # Add camera parameters if requested
        if props.include_focal_length and focal_length is not None:
            frame_data['focal_length'] = focal_length
            
        if props.include_fov and fov_degrees is not None:
            frame_data['fov'] = round(fov_degrees, 6)  # FOV in degrees
        
        return frame_data
    
    def export_camera_animation(self, camera_obj, props):
        """Main export function"""
        
        # Get frame range
        if props.use_scene_frame_range:
            frame_start = bpy.context.scene.frame_start
            frame_end = bpy.context.scene.frame_end
        else:
            frame_start = props.frame_start
            frame_end = props.frame_end
        
        # Store original frame
        original_frame = bpy.context.scene.frame_current
        
        # Collect camera data for all frames
        camera_data = {
            'camera_name': camera_obj.name,
            'frame_rate': bpy.context.scene.render.fps,
            'frame_start': frame_start,
            'frame_end': frame_end,
            'frame_step': props.frame_step,
            'target_distance': props.target_distance,
            'coordinate_system': props.coordinate_system,
            'total_frames': len(range(frame_start, frame_end + 1, props.frame_step)),
            'poses': []
        }
        
        # Add metadata if requested
        if props.include_metadata:
            camera_data.update({
                'blender_version': bpy.app.version_string,
                'export_timestamp': datetime.now().isoformat(),
                'coordinate_precision': props.coordinate_precision,
            })
        
        # Export each frame
        frames_to_export = list(range(frame_start, frame_end + 1, props.frame_step))
        debug_positions = []  # Store positions for debugging
        
        for i, frame in enumerate(frames_to_export):
            try:
                frame_data = self.get_camera_data_at_frame(camera_obj, frame, props)
                camera_data['poses'].append(frame_data)
                debug_positions.append(f"Frame {frame}: {frame_data['position']}")
                
                # Update progress (could add a progress bar here)
                progress = (i + 1) / len(frames_to_export) * 100
                print(f"Export progress: {progress:.1f}% ({i + 1}/{len(frames_to_export)} frames)")
                
            except Exception as e:
                print(f"ERROR: Failed to export frame {frame}: {str(e)}")
                continue
        
        # Check if all positions are identical (debugging)
        if len(debug_positions) > 1:
            first_pos = camera_data['poses'][0]['position']
            identical = all(pose['position'] == first_pos for pose in camera_data['poses'])
            if identical:
                debug_msg = "⚠️  WARNING: All camera positions are identical!\n"
                debug_msg += "This usually means the camera has no keyframes or isn't animated.\n"
                debug_msg += "Positions found:\n"
                for pos_info in debug_positions[:5]:  # Show first 5
                    debug_msg += f"  {pos_info}\n"
                print(debug_msg)
                self.report({'WARNING'}, "All camera positions are identical - check console for details")
        
        # Restore original frame
        bpy.context.scene.frame_set(original_frame)
        
        # Save to JSON file
        try:
            # Ensure directory exists
            output_path = bpy.path.abspath(props.output_path)
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            
            with open(output_path, 'w') as f:
                json.dump(camera_data, f, indent=2)
            
            print(f"✅ SUCCESS!")
            print(f"Exported {len(camera_data['poses'])} camera poses to: {output_path}")
            
            return True
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to save file: {str(e)}")
            return False


class SUPERSPLAT_OT_select_camera(Operator):
    """Select a camera in the scene"""
    bl_idname = "supersplat.select_camera"
    bl_label = "Select Camera"
    bl_description = "Select the camera to export"
    bl_options = {'REGISTER', 'UNDO'}
    
    camera_name: StringProperty()
    
    def execute(self, context):
        """Select the specified camera"""
        scene = context.scene
        props = scene.supersplat_camera
        
        if self.camera_name and self.camera_name != "NONE":
            camera_obj = bpy.data.objects.get(self.camera_name)
            if camera_obj:
                # Select and make active
                bpy.ops.object.select_all(action='DESELECT')
                camera_obj.select_set(True)
                context.view_layer.objects.active = camera_obj
                
                # Update properties
                props.selected_camera = self.camera_name
                
                self.report({'INFO'}, f"Selected camera: {self.camera_name}")
            else:
                self.report({'ERROR'}, f"Camera '{self.camera_name}' not found!")
                
        return {'FINISHED'}


class SUPERSPLAT_OT_validate_setup(Operator):
    """Validate the current export setup"""
    bl_idname = "supersplat.validate_setup"
    bl_label = "Validate Setup"
    bl_description = "Check if the current setup is ready for export"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        """Validate the export setup"""
        scene = context.scene
        props = scene.supersplat_camera
        
        errors = []
        warnings = []
        
        # Check camera selection
        if props.selected_camera == "NONE":
            errors.append("No camera selected")
        else:
            camera_obj = bpy.data.objects.get(props.selected_camera)
            if not camera_obj:
                errors.append(f"Selected camera '{props.selected_camera}' not found")
            elif camera_obj.type != 'CAMERA':
                errors.append(f"Object '{props.selected_camera}' is not a camera")
        
        # Check output path
        if not props.output_path:
            errors.append("No output path specified")
        else:
            try:
                output_dir = os.path.dirname(bpy.path.abspath(props.output_path))
                if not os.path.exists(output_dir):
                    warnings.append(f"Output directory does not exist: {output_dir}")
            except Exception as e:
                errors.append(f"Invalid output path: {str(e)}")
        
        # Check frame range
        if not props.use_scene_frame_range:
            if props.frame_start >= props.frame_end:
                errors.append("Start frame must be less than end frame")
        
        # Check for keyframes with detailed info
        if props.selected_camera != "NONE":
            camera_obj = bpy.data.objects.get(props.selected_camera)
            if camera_obj:
                if camera_obj.animation_data:
                    if camera_obj.animation_data.action:
                        fcurves = camera_obj.animation_data.action.fcurves
                        location_curves = [f for f in fcurves if f.data_path == 'location']
                        rotation_curves = [f for f in fcurves if f.data_path in ['rotation_euler', 'rotation_quaternion']]
                        
                        if len(location_curves) == 0 and len(rotation_curves) == 0:
                            errors.append("Camera has no location or rotation keyframes")
                        else:
                            info_msg = f"Camera has {len(location_curves)} location curves, {len(rotation_curves)} rotation curves"
                            warnings.append(info_msg)
                            
                            # Test frame sampling
                            test_frame = props.frame_start if not props.use_scene_frame_range else bpy.context.scene.frame_start
                            original_frame = bpy.context.scene.frame_current
                            
                            bpy.context.scene.frame_set(test_frame)
                            pos1 = camera_obj.matrix_world.translation.copy()
                            
                            bpy.context.scene.frame_set(test_frame + props.frame_step)
                            pos2 = camera_obj.matrix_world.translation.copy()
                            
                            bpy.context.scene.frame_set(original_frame)
                            
                            distance = (pos2 - pos1).length
                            if distance < 0.0001:
                                warnings.append(f"Camera position barely changes between frames (distance: {distance:.6f})")
                            else:
                                warnings.append(f"Camera moves {distance:.3f} units between test frames")
                    else:
                        errors.append("Camera has no action/animation")
                else:
                    errors.append("Camera has no animation data")
            else:
                errors.append("Camera object not found")
        
        # Update status
        if errors:
            props.validation_error = True
            props.validation_status = f"Errors: {'; '.join(errors)}"
            self.report({'ERROR'}, f"Validation failed: {'; '.join(errors)}")
        elif warnings:
            props.validation_error = False
            props.validation_status = f"Warnings: {'; '.join(warnings)}"
            self.report({'WARNING'}, f"Validation warnings: {'; '.join(warnings)}")
        else:
            props.validation_error = False
            props.validation_status = "Ready to export"
            self.report({'INFO'}, "Validation passed - ready to export!")
        
        return {'FINISHED'}


class SUPERSPLAT_OT_test_camera_sampling(Operator):
    """Test camera position sampling across frames"""
    bl_idname = "supersplat.test_camera_sampling"
    bl_label = "Test Camera Sampling"
    bl_description = "Test if camera position changes across frames"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        """Test camera sampling"""
        scene = context.scene
        props = scene.supersplat_camera
        
        if props.selected_camera == "NONE":
            self.report({'ERROR'}, "No camera selected")
            return {'CANCELLED'}
            
        camera_obj = bpy.data.objects.get(props.selected_camera)
        if not camera_obj:
            self.report({'ERROR'}, "Camera not found")
            return {'CANCELLED'}
        
        # Store original frame
        original_frame = bpy.context.scene.frame_current
        
        # Test sampling at different frames
        test_frames = [1, 50, 100, 150, 200]
        results = []
        positions = []
        
        for frame in test_frames:
            # Set frame
            bpy.context.scene.frame_set(frame)
            # Force update
            bpy.context.view_layer.update() 
            # Get position
            pos = camera_obj.matrix_world.translation.copy()
            positions.append(pos)
            results.append(f"Frame {frame}: [{pos.x:.3f}, {pos.y:.3f}, {pos.z:.3f}]")
        
        # Restore frame
        bpy.context.scene.frame_set(original_frame)
        
        # Check if positions are different (compare actual coordinates, not just distance from origin)
        all_same = True
        if len(positions) > 1:
            first_pos = positions[0]
            for pos in positions[1:]:
                distance = (pos - first_pos).length
                if distance > 0.001:  # More than 1mm difference
                    all_same = False
                    break
        
        # Report results
        result_msg = "Camera Sampling Test Results:\n"
        for result in results:
            result_msg += result + "\n"
            
        if all_same:
            result_msg += "\n⚠️  All positions are identical - camera may not be animated"
            self.report({'WARNING'}, "Camera positions identical across frames")
        else:
            result_msg += "\n✅ Camera positions change across frames"
            self.report({'INFO'}, "Camera animation detected")
            
        print(result_msg)
        
        return {'FINISHED'}


class SUPERSPLAT_OT_create_curve_animation(Operator):
    """Create camera animation along curve with tracking"""
    bl_idname = "supersplat.create_curve_animation"
    bl_label = "Create Camera Curve Animation"
    bl_description = "Create smooth camera animation along a curve path"
    bl_options = {'REGISTER', 'UNDO'}
    
    def get_first_point_on_curve(self, curve_obj):
        """Get the world position of the first point on the curve"""
        if curve_obj.type != 'CURVE':
            return None
            
        curve_data = curve_obj.data
        if len(curve_data.splines) == 0:
            return None
            
        spline = curve_data.splines[0]
        
        # Get the first point based on spline type
        if spline.type == 'BEZIER':
            if len(spline.bezier_points) > 0:
                first_point = spline.bezier_points[0].co
        else:  # POLY, NURBS
            if len(spline.points) > 0:
                first_point = spline.points[0].co.xyz
        
        # Transform to world coordinates
        return curve_obj.matrix_world @ first_point
    
    def get_curve_point_at_offset(self, context, curve_obj, offset):
        """Get world position at specified offset along curve"""
        # Create a temporary object to get position
        bpy.ops.object.empty_add(type='PLAIN_AXES')
        temp_obj = context.active_object
        
        # Add follow path constraint
        constraint = temp_obj.constraints.new(type='FOLLOW_PATH')
        constraint.target = curve_obj
        constraint.use_fixed_location = True
        constraint.offset = offset
        
        # Force update
        context.view_layer.update()
        
        # Get position
        position = temp_obj.matrix_world.translation.copy()
        
        # Clean up
        bpy.data.objects.remove(temp_obj)
        
        return position
    
    def execute(self, context):
        scene = context.scene
        props = scene.supersplat_camera
        
        # Validate inputs
        if not props.curve_camera:
            self.report({'ERROR'}, "Please select a camera")
            return {'CANCELLED'}
            
        if not props.path_curve:
            self.report({'ERROR'}, "Please select a path curve")
            return {'CANCELLED'}
            
        if not props.track_target and not props.track_target_empty:
            self.report({'WARNING'}, "No track target selected. Camera will follow path without tracking.")
        
        # Setup follow path constraint
        camera = props.curve_camera
        path = props.path_curve
        
        # Make sure the curve is set up properly for path animation
        if path.type == 'CURVE':
            path.data.use_path = True
            path.data.path_duration = props.curve_frame_end - props.curve_frame_start
        
        # Remove existing follow path constraints
        for constraint in camera.constraints:
            if constraint.type == 'FOLLOW_PATH':
                camera.constraints.remove(constraint)
                
        # Remove existing track to constraints
        for constraint in camera.constraints:
            if constraint.type == 'TRACK_TO':
                camera.constraints.remove(constraint)
        
        # -------------------------
        # POSITION CAMERA ON CURVE
        # -------------------------
        if props.attach_to_curve:
            if props.attach_to_start:
                # Get first point position directly from curve data
                first_point_pos = self.get_first_point_on_curve(path)
                if first_point_pos:
                    camera.location = first_point_pos
                    self.report({'INFO'}, "Camera positioned at first curve point")
                else:
                    self.report({'WARNING'}, "Could not find first point on curve")
            else:
                # Position at offset
                offset_value = props.curve_offset if not props.follow_curve_path else 0.0
                curve_pos = self.get_curve_point_at_offset(context, path, offset_value)
                camera.location = curve_pos
                self.report({'INFO'}, "Camera positioned at offset point on curve")
        
        # -------------------------
        # SET CAMERA TO ORIGIN
        # -------------------------
        camera.location = (0.0, 0.0, 0.0)
        
        # -------------------------
        # CREATE FOLLOW PATH CONSTRAINT
        # -------------------------
        follow_path = camera.constraints.new(type='FOLLOW_PATH')
        follow_path.target = path
        follow_path.use_curve_follow = props.use_curve_follow
        follow_path.forward_axis = 'FORWARD_Y'  # Default camera looks along Y axis
        follow_path.up_axis = 'UP_Z'
        follow_path.use_fixed_location = False  # Allow camera to move along path
        
        # -------------------------
        # CREATE TRACKING
        # -------------------------
        track_target_obj = props.track_target
        
        # Create empty at end of curve if requested
        if props.track_target_empty and not track_target_obj:
            # Get the last point of the curve for the empty
            if path.type == 'CURVE' and len(path.data.splines) > 0:
                spline = path.data.splines[0]
                
                if spline.type == 'BEZIER' and len(spline.bezier_points) > 0:
                    # Get last bezier point
                    last_point = spline.bezier_points[-1].co
                    last_point_world = path.matrix_world @ last_point
                elif len(spline.points) > 0:
                    # Get last point
                    last_point = spline.points[-1].co.xyz
                    last_point_world = path.matrix_world @ last_point
                else:
                    # Fallback - just put it ahead of camera
                    last_point_world = camera.location + Vector((0, 0, -10))
                
                # Create empty
                bpy.ops.object.empty_add(type='PLAIN_AXES', location=last_point_world)
                track_target_obj = context.active_object
                track_target_obj.name = f"TrackTarget_{camera.name}"
                self.report({'INFO'}, f"Created track target: {track_target_obj.name}")
                
                # Select camera again
                track_target_obj.select_set(False)
                camera.select_set(True)
                context.view_layer.objects.active = camera
        
        # Set up tracking constraint if we have a target
        if track_target_obj:
            track_to = camera.constraints.new(type='TRACK_TO')
            track_to.target = track_target_obj
            track_to.track_axis = 'TRACK_NEGATIVE_Z'  # Default camera looks along -Z
            track_to.up_axis = 'UP_Y'
            self.report({'INFO'}, f"Camera tracking: {track_target_obj.name}")
        
        # -------------------------
        # SET UP ANIMATION
        # -------------------------
        if props.follow_curve_path:
            # Create animation data if it doesn't exist
            if not camera.animation_data:
                camera.animation_data_create()
            
            # Make sure path data is prepared
            path.data.use_path = True
            path.data.path_duration = props.curve_frame_end - props.curve_frame_start
            
            # Set keyframes for path animation
            follow_path.offset = 0.0
            follow_path.keyframe_insert("offset", frame=props.curve_frame_start)
            
            follow_path.offset = 1.0
            follow_path.keyframe_insert("offset", frame=props.curve_frame_end)
            
            # Create f-curve for smooth animation
            if camera.animation_data and camera.animation_data.action:
                for fc in camera.animation_data.action.fcurves:
                    if fc.data_path == 'constraints["Follow Path"].offset':
                        for kfp in fc.keyframe_points:
                            kfp.interpolation = 'LINEAR'
            
            # Set frame range
            context.scene.frame_start = props.curve_frame_start
            context.scene.frame_end = props.curve_frame_end
            
            # Auto-sync the curve camera to the export camera for convenience
            if not props.selected_camera or props.selected_camera == "NONE":
                # Find the camera in the enum and set it
                for item in bpy.types.Scene.supersplat_camera.bl_rna.properties['selected_camera'].enum_items:
                    if item.identifier == camera.name:
                        props.selected_camera = camera.name
                        break
        else:
            # Just set static offset
            follow_path.offset = props.curve_offset
        
        self.report({'INFO'}, "Camera animation created successfully")
        return {'FINISHED'}
