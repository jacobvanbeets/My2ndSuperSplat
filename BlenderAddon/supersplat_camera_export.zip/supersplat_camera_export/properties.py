"""
Properties for SuperSplat Camera Export addon
"""

import bpy
from bpy.props import (
    StringProperty,
    BoolProperty,
    IntProperty,
    FloatProperty,
    EnumProperty,
    PointerProperty,
)
from bpy.types import PropertyGroup
import os

def update_output_path(self, context):
    """Update output path when camera name changes"""
    if self.auto_filename and self.selected_camera:
        camera = bpy.data.objects.get(self.selected_camera)
        if camera:
            directory = os.path.dirname(self.output_path) if self.output_path else bpy.path.abspath("//")
            filename = f"{camera.name}_camera_animation.json"
            self.output_path = os.path.join(directory, filename)

def get_camera_items(self, context):
    """Get list of cameras in the scene"""
    items = [("NONE", "Select Camera", "Choose a camera to export")]
    
    for obj in context.scene.objects:
        if obj.type == 'CAMERA':
            items.append((obj.name, obj.name, f"Export camera: {obj.name}"))
    
    return items

class SuperSplatCameraExportProperties(PropertyGroup):
    """Properties for SuperSplat camera export"""
    
    # Camera selection
    selected_camera: EnumProperty(
        name="Camera",
        description="Camera to export",
        items=get_camera_items,
        update=update_output_path,
    )
    
    # Output settings
    output_path: StringProperty(
        name="Output Path",
        description="Path to save the JSON file",
        default="//camera_animation.json",
        subtype='FILE_PATH',
    )
    
    auto_filename: BoolProperty(
        name="Auto Filename",
        description="Automatically generate filename based on camera name",
        default=True,
        update=update_output_path,
    )
    
    # Frame range settings
    use_scene_frame_range: BoolProperty(
        name="Use Scene Frame Range",
        description="Use the scene's frame range instead of custom range",
        default=True,
    )
    
    frame_start: IntProperty(
        name="Start Frame",
        description="First frame to export",
        default=1,
        min=1,
    )
    
    frame_end: IntProperty(
        name="End Frame",
        description="Last frame to export", 
        default=250,
        min=1,
    )
    
    frame_step: IntProperty(
        name="Frame Step",
        description="Export every Nth frame (1 = every frame)",
        default=1,
        min=1,
        max=100,
    )
    
    # Coordinate system settings
    coordinate_system: EnumProperty(
        name="Coordinate System",
        description="Coordinate system conversion",
        items=[
            ('BLENDER', 'Blender (Z-up)', 'Export in Blender coordinate system (Z-up)'),
            ('SUPERSPLAT', 'SuperSplat (Y-up)', 'Convert to SuperSplat coordinate system (Y-up)'),
        ],
        default='SUPERSPLAT',
    )
    
    # Target distance
    target_distance: FloatProperty(
        name="Target Distance",
        description="Distance for look-at target calculation (in Blender units)",
        default=10.0,
        min=0.1,
        max=1000.0,
    )
    
    # Export options
    include_focal_length: BoolProperty(
        name="Include Focal Length",
        description="Export camera focal length data",
        default=True,
    )
    
    include_fov: BoolProperty(
        name="Include FOV",
        description="Export camera field of view (FOV) data for SuperSplat",
        default=True,
    )
    
    include_metadata: BoolProperty(
        name="Include Metadata",
        description="Include Blender version and export timestamp",
        default=True,
    )
    
    # Precision settings
    coordinate_precision: IntProperty(
        name="Coordinate Precision",
        description="Number of decimal places for coordinates",
        default=6,
        min=3,
        max=10,
    )
    
    # Validation status
    validation_status: StringProperty(
        name="Status",
        description="Current validation status",
        default="Ready to export",
    )
    
    validation_error: BoolProperty(
        name="Has Error",
        description="Whether there's a validation error",
        default=False,
    )
    
    # === CURVE ANIMATION PROPERTIES ===
    
    # Curve animation camera (separate from export camera selection)
    curve_camera: PointerProperty(
        name="Camera",
        description="Camera to animate along curve",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'CAMERA'
    )
    
    # Path curve selection
    path_curve: PointerProperty(
        name="Path Curve",
        description="Curve for the camera to follow",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'CURVE'
    )
    
    # Track target object/curve
    track_target: PointerProperty(
        name="Track Target",
        description="Object or curve for the camera to track",
        type=bpy.types.Object
    )
    
    track_target_empty: BoolProperty(
        name="Create Track Target",
        description="Create an empty to track at the end of the curve",
        default=False
    )
    
    # Curve animation frame settings
    curve_frame_start: IntProperty(
        name="Start Frame",
        description="First frame of the curve animation",
        default=1,
        min=0
    )
    
    curve_frame_end: IntProperty(
        name="End Frame",
        description="Last frame of the curve animation",
        default=250,
        min=1
    )
    
    follow_curve_path: BoolProperty(
        name="Animate Along Path",
        description="Animate the camera along the curve over time",
        default=True
    )
    
    use_curve_follow: BoolProperty(
        name="Use Curve Direction",
        description="Orient the camera to follow the curve's direction",
        default=True
    )
    
    curve_offset: FloatProperty(
        name="Path Offset",
        description="Static offset along the path (when not animating)",
        default=0.0,
        min=0.0,
        max=1.0,
        subtype='FACTOR'
    )
    
    attach_to_curve: BoolProperty(
        name="Attach to Curve",
        description="Physically attach camera to the curve",
        default=True
    )
    
    attach_to_start: BoolProperty(
        name="Attach to Start Vertex",
        description="Attach camera to the first vertex of the curve",
        default=False
    )
